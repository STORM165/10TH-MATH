/**
 * JKBOSE Class 10 Mathematics Quiz Application
 * Developed by Farhan
 */

const API_BASE = '/api';
let appState = {
    mode: null,
    selectedChapter: null,
    selectedYear: null,
    questions: [],
    answers: {},
    currentQuestionIndex: 0,
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    loadInitialData();
});

function setupEventListeners() {
    // Mode selection
    document.querySelectorAll('.mode-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const mode = btn.dataset.mode;
            selectMode(mode);
        });
    });

    // Quiz form
    const form = document.getElementById('quiz-form');
    if (form) {
        form.addEventListener('submit', submitQuiz);
    }

    // Navigation
    document.getElementById('prev-btn')?.addEventListener('click', previousQuestion);
    document.getElementById('next-btn')?.addEventListener('click', nextQuestion);
}

async function loadInitialData() {
    try {
        const [chapters, years] = await Promise.all([
            fetch(`${API_BASE}/chapters`).then(r => r.json()),
            fetch(`${API_BASE}/years`).then(r => r.json()),
        ]);

        renderChapters(chapters.chapters);
        renderYears(years.years);
    } catch (err) {
        console.error('Error loading data:', err);
    }
}

function renderChapters(chapters) {
    const container = document.getElementById('chapters-container');
    container.innerHTML = chapters.map(ch => `
        <button class="chapter-btn" data-chapter="${ch}" onclick="selectChapter('${ch}')">
            ${ch}
        </button>
    `).join('');
}

function renderYears(years) {
    const container = document.getElementById('years-container');
    container.innerHTML = years.map(yr => `
        <button class="year-btn" data-year="${yr}" onclick="selectYear(${yr})">
            ${yr}
        </button>
    `).join('');
}

function selectMode(mode) {
    appState.mode = mode;
    switchScreen('mode-screen', mode === 'chapter' ? 'chapter-screen' : 'year-screen');
}

async function selectChapter(chapter) {
    appState.selectedChapter = chapter;
    await loadQuestions('chapter');
}

async function selectYear(year) {
    appState.selectedYear = year;
    await loadQuestions('full');
}

async function loadQuestions(mode) {
    try {
        let url = `${API_BASE}/questions?mode=${mode}`;
        if (mode === 'chapter') {
            url += `&chapter=${encodeURIComponent(appState.selectedChapter)}`;
        } else {
            url += `&year=${appState.selectedYear}`;
        }

        const res = await fetch(url);
        const data = await res.json();

        appState.questions = data.questions;
        appState.answers = {};
        appState.currentQuestionIndex = 0;

        document.getElementById('total-q').textContent = appState.questions.length;

        switchScreen('chapter-screen', 'quiz-screen');
        if (appState.mode === 'full') {
            switchScreen('year-screen', 'quiz-screen');
        }

        renderQuestion();
    } catch (err) {
        alert('Error loading questions: ' + err.message);
    }
}

function renderQuestion() {
    const q = appState.questions[appState.currentQuestionIndex];
    const container = document.getElementById('question-container');

    const optionsHTML = Object.entries(q.options)
        .map(([key, value]) => `
            <div class="option">
                <input type="radio" name="answer" id="opt-${q.id}-${key}" value="${key}"
                    ${appState.answers[q.id] === key ? 'checked' : ''} required>
                <label for="opt-${q.id}-${key}">
                    <strong>${key}.</strong> ${value}
                </label>
            </div>
        `).join('');

    container.innerHTML = `
        <div class="question-block">
            <h3>\\(${q.question_text}\\)</h3>
            <div class="options">${optionsHTML}</div>
        </div>
    `;

    // Update progress
    document.getElementById('current-q').textContent = appState.currentQuestionIndex + 1;
    const percent = ((appState.currentQuestionIndex + 1) / appState.questions.length) * 100;
    document.getElementById('progress-fill').style.width = percent + '%';

    // Update buttons
    document.getElementById('prev-btn').disabled = appState.currentQuestionIndex === 0;
    const isLastQuestion = appState.currentQuestionIndex === appState.questions.length - 1;
    document.getElementById('next-btn').style.display = isLastQuestion ? 'none' : 'block';
    document.getElementById('submit-btn').style.display = isLastQuestion ? 'block' : 'none';

    // Re-render MathJax
    if (window.MathJax) {
        MathJax.typesetPromise([container]).catch(err => console.log(err));
    }

    // Track answer changes
    document.querySelectorAll('input[name="answer"]').forEach(radio => {
        radio.addEventListener('change', (e) => {
            appState.answers[q.id] = e.target.value;
        });
    });
}

function previousQuestion() {
    if (appState.currentQuestionIndex > 0) {
        appState.currentQuestionIndex--;
        renderQuestion();
    }
}

function nextQuestion() {
    const q = appState.questions[appState.currentQuestionIndex];
    if (appState.answers[q.id]) {
        if (appState.currentQuestionIndex < appState.questions.length - 1) {
            appState.currentQuestionIndex++;
            renderQuestion();
        }
    } else {
        alert('Please select an answer before proceeding.');
    }
}

async function submitQuiz(e) {
    e.preventDefault();

    const q = appState.questions[appState.currentQuestionIndex];
    if (!appState.answers[q.id]) {
        alert('Please answer the last question.');
        return;
    }

    try {
        const res = await fetch(`${API_BASE}/submit`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ answers: appState.answers }),
        });

        const results = await res.json();
        showResults(results);
    } catch (err) {
        alert('Error submitting quiz: ' + err.message);
    }
}

function showResults(results) {
    const percentage = results.percentage;
    let label = '😞 Keep Trying!';
    if (percentage >= 80) label = '🏆 Excellent!';
    else if (percentage >= 60) label = '✨ Good!';
    else if (percentage >= 40) label = '📚 Need More Practice';

    document.getElementById('score-percentage').textContent = results.percentage;
    document.getElementById('score-label').textContent = label;
    document.getElementById('stat-total').textContent = results.total;
    document.getElementById('stat-correct').textContent = results.correct;
    document.getElementById('stat-wrong').textContent = results.wrong;
    document.getElementById('stat-unanswered').textContent = results.unanswered;

    const detailsHTML = results.details.map((d, idx) => {
        const statusClass = d.is_correct ? 'correct' : 'incorrect';
        const badge = d.is_correct ? '✓' : '✗';

        return `
            <div class="result-item ${statusClass}">
                <div class="result-item-question">
                    <span class="result-badge ${statusClass}">${badge}</span>
                    Question ${idx + 1}: \\(${d.question}\\)
                </div>
                <div class="result-item-answer ${d.is_correct ? 'correct' : 'user'}">
                    Your answer: <strong>${d.user_answer || 'Not answered'}</strong>
                </div>
                ${!d.is_correct ? `
                    <div class="result-item-answer correct">
                        Correct answer: <strong>${d.correct_answer}</strong>
                    </div>
                ` : ''}
                <div class="result-item-explanation">
                    📖 ${d.explanation}
                </div>
            </div>
        `;
    }).join('');

    document.getElementById('results-details').innerHTML = detailsHTML;
    switchScreen('quiz-screen', 'results-screen');

    // Re-render MathJax
    if (window.MathJax) {
        MathJax.typesetPromise([document.getElementById('results-screen')])
            .catch(err => console.log(err));
    }
}

function backToMode() {
    appState.selectedChapter = null;
    appState.selectedYear = null;
    switchScreen('chapter-screen', 'mode-screen');
    switchScreen('year-screen', 'mode-screen');
    switchScreen('quiz-screen', 'mode-screen');
    switchScreen('results-screen', 'mode-screen');
}

function switchScreen(fromId, toId) {
    const fromScreen = document.getElementById(fromId);
    const toScreen = document.getElementById(toId);

    if (fromScreen) fromScreen.classList.remove('active');
    if (toScreen) toScreen.classList.add('active');
}
