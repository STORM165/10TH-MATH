window.MathJax = {
    tex: {
        inlineMath: [['$', '$'], ['\\(', '\\)']],
        displayMath: [['$$', '$$'], ['\\[', '\\]']],
        processEscapes: true,
    },
    svg: {
        fontCache: 'global'
    },
    startup: {
        ready: () => {
            MathJax.startup.defaultReady();
            console.log('✓ MathJax loaded');
        }
    }
};
